library(caret)
library(readr)
library(rstudioapi)
library(e1071)
library(dplyr)
library(rpart)

#For cleaning variables
rm(list = setdiff(ls(), lsf.str()))

current_path = getActiveDocumentContext()$path
setwd(dirname(current_path))
setwd("..")
rm(current_path)
EP <- read.csv( file ="./data/Epa.csv" , header = TRUE , sep = ',')
NP <- read.csv(file = "./data/Npa.csv", header = TRUE , sep =',')


#### Pre Processing ####
EP <- EP[,c(1,5,9,18)]
EP <- PPfunction(EP)
EP <- RmOut(EP)

#### Training and Testing sets ####

List <- TrainAndTestSets(EP$Volume,0.75,EP,233)

#### Random Forest ####
ModelRandomForest <- TrainingFunction("rf",Volume~.,List$trainingSet,5)

PredictionRandomForest <- predict(ModelRandomForest,List$testingSet)

TestResultsRF <- postResample(PredictionRandomForest,List$testingSet$Volume)

#### SVM ####

svm.model <- TrainingFunction("svm",Volume~.,List$trainingSet,5,100000,0.00001)  

svm.pred <- predict(svm.model,List$testingSet)

TestResultsSVM <- postResample(svm.pred,List$testingSet$Volume)
#### knn ####

Normal <- normalize(EP[,c(13,14,15)])


EPNormal <- cbind(EP[c(1,2,3,4,5,6,7,8,9,10,11,12)],Normal)






KnnList <- TrainAndTestSets(EPNormal$Volume,0.75,EPNormal,233)

KNN <- TrainingFunction("knn",Volume~.,KnnList$trainingSet,5)

KnnPrediction <- predict(KNN,List$testingSet)

TestResultsKNN <-postResample(KnnPrediction,KnnList$testingSet$Volume)


####


AllTestResults <- cbind(TestResultsKNN,TestResultsRF,TestResultsSVM)

AllTestResults              


#### Training All 3 models at once #### 

methods <- c("rf","knn","svm")

Models <- vector(mode = "list" , length = 3)

for(i in 1:length(methods))
{
  
  if (methods[i] == "knn" ) 
    
  {
    
    Normal <- normalize(EP[,c(13,14,15)])
    
    EPNormal <- cbind(EP[c(1,2,3,4,5,6,7,8,9,10,11,12)],Normal)
    
    ListN <- TrainAndTestSets(EP$Volume,0.75,EPNormal,288)
    
    Models[[i]] <- TrainingFunction(methods[i],Volume~.,ListN$trainingSet,5)
    
    
  }
  else
  {  
    
    Models[[i]] <- TrainingFunction(methods[i],Volume~.,List$trainingSet,5)
    
  }
  
}

for( i in 1:3){
  


print(Models[[i]])


}



