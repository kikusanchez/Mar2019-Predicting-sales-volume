#### Train and Test Set function ####


TrainAndTestSets <- function(label,p,data,seed){
  set.seed(seed)
  
  inTrain <- createDataPartition(y= label, p = p , list = FALSE)
  training <- data[inTrain,]
  testing <- data[-inTrain,]
  
  
  list(trainingSet=training,testingSet = testing)
  
}







#### Training Functions ####


TrainingFunction <- function(method,formula,data,tune,c=1000,gamma=0.0001)
  {
  
  fitcontrol <-  trainControl(method = "repeatedcv", repeats = 4)
  
  if(method == "rf") {
    
    Model <- train(formula, data = data,method = method, trcontrol = fitcontrol , tunelenght = tune)  
  }

  else if (method == "knn"){
    
    
    
    Model <- train(formula, data = data,method = method, trcontrol = fitcontrol , tunelenght = tune,
                   preProcess = c("center", "scale"))  
  
    
    }
  
   
  else if (method == "svm"){ 
     
    Model <- svm(formula, data = data,cost=c , gamma = gamma)
  
    
    }

    return(Model)
  }


#### Al 3 models at once ####

TrainAll3Models <- function (formula,data)
  {

  Model <- vector(mode="list", length=length(methods))

      methods <- c("rf","svm","knn")
        
      for(i in 1:length(methods))
          {    
      
            Model[[i]] <- TrainingFunction(methods[i],formula,data,5)

                

      }
      Model
}










